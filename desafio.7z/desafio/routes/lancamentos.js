import express from 'express';
import { promises } from 'fs';
import {insertRecipes, totalMonth} from '../controllers/lancamentosController.js'
global.fileName = "lancamentos.json"

const {writeFile, readFile} = promises
const router = express.Router()

router.post("/receita", async (req, res) =>{
    try{
        res.send(await insertRecipes(req.body))

    } catch (err) {
        res.status(400).send(err.message)
    }
})

router.post("/despesa", async (req, res) =>{
    try{
        res.send(await insertRecipes(req.body, "D"))

    } catch (err) {
        res.status(400).send(err.message)
    }
})

router.get("/totalMes/:mes/?:pessoa", async (req, res) =>{
    try{
        res.send(await totalMonth(parseInt(req.params.mes), req.params.pessoa))
    } catch (err) {
        res.status(400).send(err.message)
    }
})

export default router