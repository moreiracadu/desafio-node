import { promises } from 'fs';
import moment from 'moment';
import calc from '../libs/calculos.js'

const {writeFile, readFile} = promises

async function insertRecipes (lancamento, tipo) {
    const json = JSON.parse(await readFile(global.fileName))

    lancamento = {id: json.nextId++, ...lancamento}
    if (tipo === "D"){
        lancamento.valor = lancamento.valor *-1
    }
    json.lancamentos.push(lancamento)
    await writeFile(global.fileName, JSON.stringify(json))

    return lancamento
}

async function totalMonth(month, person) {
    const json = JSON.parse(await readFile(global.fileName))

    let lancamentos = json.lancamentos.filter(lancamento =>{
        if (person) {
            if (lancamento.name === person){
                const m = moment(lancamento.data, "DD/MM/YYYY").month() +1
                return m === month
            }
        }
        else {
            const m = moment(lancamento.data, "DD/MM/YYYY").month() +1
            return m === month
        }
    })

    lancamentos =  lancamentos.map(lancamento =>{
        return lancamento.valor
    })
    return {total: calc.sumTransactions(lancamentos)}
}

export {insertRecipes, totalMonth}