import express from 'express'
import {promises} from 'fs'
import router from './routes/lancamentos.js'

const {writeFile, readFile} = promises

const app = express()
app.use(express.json())
app.use('/lancamentos', router)

app.listen(3000, async () =>{
    try{
        console.log('Api has staterd succesfully!')
        
        const initialJson = {
        nextId: 1,
            lancamentos: []
        }
        
        await writeFile(global.fileName, JSON.stringify(initialJson), {flag: "wx"})

    } catch (err) {
        console.log(err)
    }
})